#!/bin/bash
echo '/home/user/.nvm/versions/node/v6.4.0/bin/shipit seed3 app.deploy'
PATH=$PATH:/home/user/.nvm/versions/node/v6.4.0/bin/
cd /media/sf_projects/crypto/deploy_nodejs/breedv2
/home/user/.nvm/versions/node/v6.4.0/bin/shipit seed3 app.deploy