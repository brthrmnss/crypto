#!/bin/bash
cd /media/psf/Dropbox/projects/crypto/deploy_nodejs/ritv;
/home/user/.nvm/versions/node/v0.12.5/bin/shipit staging list
exit

#source ~/.nvm/nvm.sh
#nvm use 0;
echo 'what'
echo $PATH
 whoami
#export PATH
cd /media/psf/Dropbox/projects/crypto/mp/RemoteConsoleServer
cd /media/psf/Dropbox/projects/crypto/mp
cd /media/psf/Dropbox/projects/crypto/deploy_nodejs/ritv;
pwd
source ~/.profile

#source ~/.nvm/nvm.sh
source ~/.profile
source ~/.bashrc
shipit staging list
exit
#bash cd "/media/psf/Dropbox/projects/crypto/deploy_nodejs/ritv/"; shipit staging list

cd /media/psf/Dropbox/projects/crypto/deploy_nodejs/ritv/
#/media/psf/Dropbox/projects/crypto/deploy_nodejs/breedv2/shipitfile.js
cd /media/psf/Dropbox/projects/crypto/mp/RemoteConsoleServer/
shipit staging list