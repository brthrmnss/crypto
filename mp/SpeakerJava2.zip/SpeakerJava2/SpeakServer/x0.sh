#!/bin/bash
echo 'what'
#bash cd "/media/psf/Dropbox/projects/crypto/deploy_nodejs/ritv/"; shipit staging list
#source ~/.profile
cd /media/psf/Dropbox/projects/crypto/deploy_nodejs/ritv/
#/media/psf/Dropbox/projects/crypto/deploy_nodejs/breedv2/shipitfile.js
#cd /media/psf/Dropbox/projects/crypto/mp/RemoteConsoleServer/
shipit staging list